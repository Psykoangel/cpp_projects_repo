
extern int foo(int x) ; 
extern int bar(int x) ; 

