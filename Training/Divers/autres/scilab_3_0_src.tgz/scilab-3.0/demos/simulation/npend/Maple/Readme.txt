

Npend.map : Maple source who creates 
	npend.f, ener.f and np.f 
		
	n the dimension of the pendulum can be changed in Npend.map 


Euler.map : Genral code dealing with euler equations used by Npend.map

all.tex : include systeme.tex which gives in TeX the computations of Maple
	systeme.tex is automatically generated 

WARNING : If you are using MapleV.4 yopu should change the add function into 
	matadd in npend.map and Euler.map 

